<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($nama); ?></title>
</head>
<body>
    <h1> saya <?php echo e($nama); ?> </h1>
    <ul>
        <li>tanggal lahir <?php echo e($tanggal_lahir); ?></li>
        <li>tempat <?php echo e($tempat); ?></li>
        <li></li>
    </ul>
</body>
</html>
<?php /**PATH /Users/andisaputra/assesment_2/example-app/resources/views/tabel.blade.php ENDPATH**/ ?>